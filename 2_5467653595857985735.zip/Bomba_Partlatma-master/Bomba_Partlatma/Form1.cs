using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace Bomba_Partlatma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Click += button1_Click;
            button2.Click += button2_Click;
            button3.Click += button3_Click;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        Random r = new Random();
        Random g = new Random();
        Random b = new Random();

        Random xL = new Random();
        Random yL = new Random();
        int count = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            count++;
            Panel p = new Panel();
            p.Size = new Size(60, 60);
            p.BackColor = Color.FromArgb(r.Next(0, 256), g.Next(0, 256), b.Next(0, 256));
            p.Location = new Point(xL.Next(0, 850), yL.Next(0, 350));

            this.Controls.Add(p);
            p.BringToFront();
            label2.Text = count.ToString();
            if (p.Bounds.IntersectsWith(pictureBox1.Bounds))
            {
                OyunBitdi();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(xL.Next(0, 850), yL.Next(0, 350));

            foreach (Control item in this.Controls)
            {
                if (item is Panel)
                {
                    if (pictureBox1.Bounds.IntersectsWith(item.Bounds))
                    {
                        OyunBitdi();
                        break;
                    }
                }
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }
        private void OyunBitdi()
        {
            try
            {
                SoundPlayer ses = new SoundPlayer("bomba.wav");
                ses.Play();
            }
            catch
            {
            }

            DialogResult netice = MessageBox.Show("Bomba ilə panel toqquşdu! Oyun bitdi.", "Partlayış!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (netice == DialogResult.OK)
            {
                OyunSifirla();
            }
        }
        private void OyunSifirla()
        {
            for (int i = this.Controls.Count - 1; i >= 0; i--)
            {
                if (this.Controls[i] is Panel)
                {
                    this.Controls.RemoveAt(i);
                }
            }

            count = 0;
            label2.Text = "0";
            pictureBox1.Location = new Point(85, 140);
        }
    }
}